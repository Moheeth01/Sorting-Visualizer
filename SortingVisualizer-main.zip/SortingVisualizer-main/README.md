# Sorting_Visualizer
Sorting Visualizer using HTML, CSS, and Javascript, allowing users to visualize popular sorting algorithms such as Bubble sort, Insertion Sort and also enhances the understanding of complex sorting algorithms
